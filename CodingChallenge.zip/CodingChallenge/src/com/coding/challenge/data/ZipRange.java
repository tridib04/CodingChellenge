package com.coding.challenge.data;

/**
 * Pojo class to hold upperBound and lowerBound ZipCode. Since each set contains
 * two zipCodes so the pojo defines two primitives
 * 
 * @author tridib
 *
 */
public class ZipRange {

	private int lowerBound;
	private int upperBound;

	public int getLowerBound() {
		return lowerBound;
	}

	public void setLowerBound(int lowerBound) {
		this.lowerBound = lowerBound;
	}

	public int getUpperBound() {
		return upperBound;
	}

	public void setUpperBound(int upperBound) {
		this.upperBound = upperBound;
	}

	/**
	 * toString method to only print the number within the brackets.
	 */
	@Override
	public String toString() {
		return String.format("['%d','%d']", lowerBound, upperBound);
	}

	public ZipRange(int lowerBound, int upperBound) {
		if (lowerBound <= upperBound) {
			this.lowerBound = lowerBound;
			this.upperBound = upperBound;
		} else {
			this.lowerBound = upperBound;
			this.upperBound = lowerBound;
		}
	}

	/**
	 * Auto Generated Hashcode and Equals.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + lowerBound;
		result = prime * result + upperBound;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ZipRange other = (ZipRange) obj;
		if (lowerBound != other.lowerBound)
			return false;
		if (upperBound != other.upperBound)
			return false;
		return true;
	}

}
