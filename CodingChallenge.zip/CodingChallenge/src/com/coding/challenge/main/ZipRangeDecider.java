package com.coding.challenge.main;

import java.util.logging.Logger;

import com.coding.challenge.data.ZipRange;
import com.coding.challenge.exception.ZipRangeException;
import com.coding.challenge.service.RangeMergerImpl;

/**
 * Runner class to implement the minimum number of ranges required to represent
 * the same restrictions as the input.
 * 
 * @author tridib
 *
 */
public class ZipRangeDecider {

	private static final Logger log = Logger.getLogger(ZipRangeDecider.class.getName());
	
	public static void main(String[] args) throws ZipRangeException {
		// TODO Auto-generated method stub

		log.info("Starting ZipRangeDecider");
		ZipRange zipRange1 = new ZipRange(94133, 94133);
		ZipRange zipRange2 = new ZipRange(94200, 94299);
		ZipRange zipRange3 = new ZipRange(94226, 94399);

		
		RangeMergerImpl mergerImpl = new RangeMergerImpl();
		mergerImpl.mergeLists(zipRange1);
		mergerImpl.mergeLists(zipRange2);
		mergerImpl.mergeLists(zipRange3);

		log.info("New merged list");
		mergerImpl.printRange();
		log.info("ZipRangeDecider finished");
	}

}
