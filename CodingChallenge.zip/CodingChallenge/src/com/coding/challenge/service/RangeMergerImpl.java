package com.coding.challenge.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import com.coding.challenge.data.ZipRange;
import com.coding.challenge.exception.ZipRangeException;
import com.coding.challenge.util.ZipRangeValidator;

/**
 * ZipMerger Implementation Class.
 * 
 * @author tridib
 *
 */
public class RangeMergerImpl {

	private static final Logger log = Logger.getLogger(RangeMergerImpl.class.getName());

	// Create a new list to hold the new merged list.
	List<ZipRange> zipRangeLists = new ArrayList<ZipRange>();

	public void mergeLists(ZipRange zRange) throws ZipRangeException {

		/**
		 * Validation of the ZipRange Class and its lower and Upper bound. If
		 * Valid data then proceed otherwise throw exception "Not a Valid Zip"
		 */

		log.info("mergeLists() method entry");
		ZipRangeValidator validator = new ZipRangeValidator();
		boolean isValid = validator.validate(zRange);

		if (isValid) {

			log.info("Valid Zip");
			/**
			 * If the list is empty (intial first run case), then add the
			 * ZipRange object to the list. Otherwise merge the range if it
			 * overlaps with the existing range.
			 */

			if (zipRangeLists.size() != 0) {

				log.info("ZipRangeList is not empty checking overlaps");
				Iterator<ZipRange> iter = zipRangeLists.iterator();

				// Flag to hold if it is required to add to the list or not.
				boolean toAdd = true;

				while (iter.hasNext()) {
					ZipRange range = iter.next();

					/**
					 * If the new range exists with the existing range no need
					 * to add, set flag to false.
					 */
					if (range.getLowerBound() <= zRange.getLowerBound()
							&& range.getUpperBound() >= zRange.getUpperBound()) {
						toAdd = false;
						log.info("Range within existing range in the list");
					}

					/**
					 * If the new range doesn't exists with the existing range
					 * need to add, set flag to true.
					 */
					else if (range.getLowerBound() > zRange.getUpperBound()
							|| range.getUpperBound() < zRange.getLowerBound()) {
						toAdd = true;
						log.info("Range doesn't exist within the range from the list");
					}

					/**
					 * If the range overlaps , merge them, set flag to true.
					 */
					else {
						if (range.getLowerBound() < zRange.getLowerBound()) {
							zRange.setLowerBound(range.getLowerBound());
						}
						if (range.getUpperBound() > zRange.getUpperBound()) {
							zRange.setUpperBound(range.getUpperBound());
						}
						iter.remove();
						toAdd = true;
						log.info("Range overlaps with the range from the list");
					}
				}

				// If toAdd flag is true, add the Object to the list
				if (toAdd) {
					zipRangeLists.add(zRange);
				}
			} else {

				log.info("List empty adding the zip to the list. Initial run");
				// Inital case when the list is empty
				zipRangeLists.add(zRange);
			}
		} else {
			log.info("Not Valid Zip");
			throw new ZipRangeException("Not a Valid ZipCode");
			// throw exception
		}

	}

	/**
	 * Print the new merged list
	 */
	public void printRange() {

		if (zipRangeLists.size() > 0) {
			for (ZipRange range : zipRangeLists) {
				System.out.print(range.toString());
			}
		}

	}

	/**
	 * Utility method to be used by Unit test to check the content of the list
	 * 
	 * @return list
	 */
	public List<ZipRange> getZipRangeList() {
		return zipRangeLists;
	}

}
