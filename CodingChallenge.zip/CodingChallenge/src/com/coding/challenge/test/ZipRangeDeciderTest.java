package com.coding.challenge.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.coding.challenge.data.ZipRange;
import com.coding.challenge.exception.ZipRangeException;
import com.coding.challenge.service.RangeMergerImpl;

public class ZipRangeDeciderTest {

	List<ZipRange> expectedList = new ArrayList<ZipRange>();
	RangeMergerImpl mergerImpl = new RangeMergerImpl();

	/**
	 * Test Null Data
	 * 
	 * @throws ZipRangeException
	 */
	@Test(expected = ZipRangeException.class)
	public void checkNullRange() throws ZipRangeException {
		ZipRange zRange = null;
		mergerImpl.mergeLists(zRange);
	}

	/**
	 * Test Invalid ZipCode Length
	 * 
	 * @throws ZipRangeException
	 */
	@Test(expected = ZipRangeException.class)
	public void checkInValidZipCode() throws ZipRangeException {
		ZipRange zRange = new ZipRange(22, 33);
		mergerImpl.mergeLists(zRange);
	}

	/**
	 * Test Valid Data
	 * 
	 * @throws ZipRangeException
	 */
	@Test
	public void checkOriginalValues() throws ZipRangeException {

		ZipRange zipRange1 = new ZipRange(94133, 94133);
		ZipRange zipRange2 = new ZipRange(94200, 94299);
		ZipRange zipRange3 = new ZipRange(94226, 94399);

		mergerImpl.mergeLists(zipRange1);
		mergerImpl.mergeLists(zipRange2);
		mergerImpl.mergeLists(zipRange3);

		// Expected List
		// ['94133','94133']['94200','94399']
		ZipRange expRange1 = new ZipRange(94133, 94133);
		ZipRange expRange2 = new ZipRange(94200, 94399);
		expectedList.add(expRange1);
		expectedList.add(expRange2);

		Assert.assertEquals("Success - expected result content match", expectedList, mergerImpl.getZipRangeList());

	}

}
