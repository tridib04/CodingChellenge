package com.coding.challenge.util;

import com.coding.challenge.data.ZipRange;

public class ZipRangeValidator {

	private static final String VALID_REGEX = "[0-9]{5}";

	/**
	 * Validate method which validates if the given ZipRange object is not null.
	 * if Not null then checks if the lowerBound and UpperBound is not null. If
	 * either of them is found null, return false to throw custom exception
	 * 
	 * @param zRange
	 * @return boolean
	 */
	public boolean validate(ZipRange zRange) {

		if (null != zRange) {
			if (zRange.getLowerBound() != 0 || zRange.getUpperBound() != 0) {
				boolean isValid = checkZipLength(zRange);
				if (isValid) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * Validation method which checks the zip is of length 5 and of number
	 * format.
	 * 
	 * @param zRange
	 * @return boolean
	 */
	private boolean checkZipLength(ZipRange zRange) {

		String lBound = Integer.toString(zRange.getLowerBound());
		String uBound = Integer.toString(zRange.getUpperBound());

		if (!lBound.matches(VALID_REGEX) || !uBound.matches(VALID_REGEX)) {
			return false;
		}
		return true;
	}

}
